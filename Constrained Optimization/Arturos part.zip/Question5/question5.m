%%Problem 5
%% Question 5.4
clear all
H=[2.3,.93,.62,.74,-.23,0;
    .93,1.4,.22,.56,.26,0;
    .62,.22,1.8,.78,-.27,0;
    .74,.56,.78,3.4,-.56,0;
    -.23,.26,-.27,-.56,2.6,0;
    0,0,0,0,0,0];
g = [0 0 0 0 0 0]';
r=[15.1;12.5;14.7;9.02;17.68;2];
A=[r,ones(6,1)];
b=[15;1];
C=eye(6);
d=zeros(6,1);
x0 = [0.2 0.2 0.2 0.2 0.1 0.1]';
[Xmine,iterations] = InteriorPointSolver(H, g, A, b, C, d, x0);
X = quadprog(H,g,-C,-d,A',b,[],[],x0);
comparison = [Xmine X]

%% Question 5.5

returns = 2.0:0.05:17.60;
varInterior = [];
varQuad = [];
for ret = returns
    b = [ret; 1];
    [xi,iterations] = InteriorPointSolver(H, g, A, b, C, d, x0);
    X = quadprog(H,g,-C,-d,A',b,[],[],x0);
    var = xi'*H*xi;
    varInterior = [varInterior, var];
    varQ = X'*H*X;
    varQuad = [varQuad, varQ];
end

figure
p = plot(returns,varInterior,'g',returns,varQuad,'b')
legend('CustomAlgorithm','QuadProg')
p(1).LineWidth = 2;

